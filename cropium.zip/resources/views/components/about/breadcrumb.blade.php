<section class="breadcrumb-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="title">about page</h2>
                    <a href="#">home</a><span> / about page</span>
                </div>
            </div>
        </div>
    </section>
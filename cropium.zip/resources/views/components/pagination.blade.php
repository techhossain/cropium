<div class="row order-md-1">
    <div class="col-lg-12">

        {{ $posts->links("vendor.pagination.bootstrap-4") }}

    </div>
</div>